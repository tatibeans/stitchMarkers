import express from 'express';
import { config } from 'dotenv';
import { join } from 'path';
import fs from 'fs';


config();

const app = express();
const port = process.env.PORT;

app.get('/', (req, res) => {
    //   res.send('Express + TypeScript Server');
    // res.sendFile(join(__dirname, '/traicion.html'));
    res.sendFile('C:/Users/Usuario/Desktop/codingPortfolio/stitchMarkers/actualCode/traicion.html')
});

app.listen(port, () => {
    console.log(`[server]: Server is running at http://localhost:${port}`);
});