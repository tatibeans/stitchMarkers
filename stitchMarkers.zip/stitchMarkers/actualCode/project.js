class Project {
    constructor(name, pieces, instructions, image) {
        this.name = name;
        this.pieces = pieces;
        this.instructions = instructions;
        this.image = image;
    }
}