class Piece {
    constructor(id, rows, instructions, image){
        this.id = id;
        this.rows = rows;
        this.instructions = instructions;
        this.image = image;
    }

    addRow(row){
        if (!this.rows.find(r => r.id == row.id)){
            this.rows.push(row);
        }
    }
}