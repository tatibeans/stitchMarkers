import { readFile } from "fs";
import readline from "readline";
var pendingColumn = false;
const stitchDefs = [];



// document.getElementById("addStitchButton").onclick(openModal())

// Function to open the modal
function openModal() {
    // Set pendingColumn to true to indicate that a column will be added after confirming data
    pendingColumn = true;

    loadStitches();
    // Show the modal
    document.getElementById("myModal").style.display = "block";
}

function defineStitch(name, numStitches, numIncrease, numDecrease, instructions) {
    if (stitchDefs.find(st => st.name === name)) return false;
    var stitch = {
        name: name.toLowerCase(),
        numStitches: numStitches,
        numIncrease: numIncrease,
        numDecrease: numDecrease,
        instructions: instructions
    };
    addStitch(stitch);
    return true;
}

function addStitch(stitch) {
    var added = false;
    for (let i = 0; i < stitchDefs.length - 1 && !added; i++) {
        if (stitch.name < stitchDefs[i].name) {
            stitchDefs.splice(i, 0, stitch);
            added = true;
        }
    }
    if (!added) {
        stitchDefs.push(stitch);
    }
}

// Function to add data to the new column
function addData() {
    var option = document.getElementById('choose-sel').value;
    if (pendingColumn) {
        var table = document.getElementById("myTable");
        var rows = table.getElementsByTagName('tr');
        var repeat = document.getElementById("numReps").value;
        for (var i = 0; i < rows.length; i++) {
            var lastCell = rows[i].getElementsByTagName('td')[rows[i].getElementsByTagName('td').length - 1];
            for (var j = 0; j < repeat; j++) {
                var cell = rows[i].insertCell(-1);
                cell.className = "stitchCell";
                cell.innerHTML = `<img src="./symbols/${option}.jpg" >`;
            }

        }
        // Reset pendingColumn to false after adding the column
        pendingColumn = false;
    }

    // Close the modal
    document.getElementById('myModal').style.display = "none";
}

function getStitchFromArray(name){
    return stitchDefs.find(st => st.name === name);
}

function getAllStitches(){
    console.log("getAllStitches");
    var stitchList = [];
    // specify the path of the CSV file
    const path = "stitches.csv";
    readFile(path, "utf8", (err, data) => {
        if (err) {
            console.error("Error while reading:", err);
            return;
        }

        // Split the data into lines
        const lines = data.split("\n");

        // Loop through each line and split it into fields
        lines.forEach((line) => {
            const fields = line.split(",");
            stitchList.push(fields);
        });
    });
    return stitchList;
}

function getStitch(name) {
    console.log("getStitch");
    var output;
    var stitchList = getAllStitches();
    // // specify the path of the CSV file
    // const path = "stitches.csv";
    // fs.readFile(path, "utf8", (err, data) => {
    //     if (err) {
    //         console.error("Error while reading:", err);
    //         return;
    //     }

    //     // Split the data into lines
    //     const lines = data.split("\n");

    //     // Loop through each line and split it into fields
    //     lines.forEach((line) => {
    //         const fields = line.split(",");
    //         stitchList.push(fields);
    //     });
    // });
    var i = 0;
    while (i < stitchList.length && !output) {
        console.log(stitchList)
        if (stitchList[i][0] == name) {
            output = stitchList[i];
            console.log(output)
        } else {
            i++;
        }
    }
}

function loadStitches(){
    console.log("loadStitches");
    var stitches = getAllStitches();
    var selectBox = document.getElementById("choose-sel");
    stitches.forEach(s => {
//         const option = document.createElement('option');
//   var text = document.getElementById('optionLabel').value;
//   option.innerText = text;
//   text = '';
//   document.getElementById('dynamic-sel').appendChild(option);
        var opt = document.createElement('option');
        opt.innerText = s.name;
        selectBox.appendChild(opt);
    })
}

getStitch("purl")

// Close the modal when the user clicks the close button
// var closeBtn = document.getElementsByClassName("close")[0];
// closeBtn.onclick = function () {
//     // Reset pendingColumn to false if the modal is closed without confirming data
//     pendingColumn = false;
//     document.getElementById('myModal').style.display = "none";
// }


var addStitchButton = document.getElementById("addStitchButton");
button.addEventListener("click", openModal);